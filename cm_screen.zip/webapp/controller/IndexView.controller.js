sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/ODataModel",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Filter",
	'./CustomerFormat',
	'./InitPage'
], function(Controller, MessageBox, ODataModel, FilterOperator, Filter, CustomerFormat, InitPage) {
	"use strict";
	var oview = "";
	var type = "Functional";
	var modulename = "SD";
	var oVizFrame = null;

	return Controller.extend("sap.ui.demo.controller.IndexView", {

		onInit: function() {
			oview = this.getView();

			var oModel = new sap.ui.model.odata.v2.ODataModel("/destinations/KE1/sap/opu/odata/sap/ZODATA_SRV/");
			oModel.read("/clientSet", {

				success: function(oData, response) {
					var oViewModel2 = new sap.ui.model.json.JSONModel();
					oViewModel2.setData(oData.results);
					oview.byId("client").setModel(oViewModel2);

				},
				error: function() {
					//	alert();

				}

			});

		},
		navView: function(oEvent) {

			var clickedData = oEvent.getParameter("data")[0].data.BusinessProcess;
			// to replace "/" as 5 in complexity area column 

			clickedData = clickedData.replace(/[/]/g, "5");

			var router = sap.ui.core.UIComponent.getRouterFor(this);

			router.navTo("navigation", {
				complexity: clickedData
			});

		},
		validate: function() {

			oview = this.getView();
			var client = oview.byId("client").getSelectedKey();
			//	alert(client);
			var date = oview.byId("date").getSelectedKey();
			if (oview.byId("client").getSelectedKey() === "") {
				MessageBox.error("Please select your client");
				return false;
			}
			/*	if (oview.byId("date").getSelectedKey() === "") {
					MessageBox.error("Please select date");
					return false;
				}
				*/
			var t = this;
			oview = this.getView();

			var oViewModel = new sap.ui.model.odata.v2.ODataModel("/destinations/KE1/sap/opu/odata/sap/ZODATA_SRV/");
			var calltype = "";
			if (type === "Functional") {
				calltype = "/functionalSet?$filter=";
			}
			if (type === "Technical") {
				calltype = "/technicalSet?$filter=";
			}
			if (type === "Combined") {
				calltype = "/combinedSet?$filter=";
			}
			var aFilter = [],
				orFilter = [];
			orFilter.push(new Filter("ModuleName", FilterOperator.EQ, modulename));
			orFilter.push(new Filter("Client", FilterOperator.EQ, "Trumpf"));
			orFilter.push(new Filter("Date1", FilterOperator.EQ, "26-Mar-17"));

			aFilter.push(new Filter(orFilter, true));

			var fnSuccess = function(oData, response) {

					/*	oModel = new sap.ui.model.json.JSONModel();

						oModel.setData(oData.results);*/
					/*	t.oVizFrame.setModel(oModel);
						var oTooltip = new sap.viz.ui5.controls.VizTooltip({});
						oTooltip.connect(oVizFrame.getVizUid());*/

					//			=== === === === === === === === === === =

					var counter_of_bp = 0;
					var pm_score = 0;
					var abpc_score = 0;

					var arr_evalbp = [];
					var arr_pscore = [];
					var arr_abpc = [];
					var arr_CL = [];
					var finaldata = [];

					for (var i = 0; i < oData.results.length; i++) {
						counter_of_bp = 0;
						var bpk = 0;
						pm_score = 0;
						var status = 'false';
						var bp = oData.results[i].BusinessProcess;
						if (arr_evalbp.length > 1) {
							for (var k = 0; k < arr_evalbp.length; k++) {

								if (bp === arr_evalbp[k]) {
									status = 'true';
								}
							}

							if (status === 'false') {
								for (var j = 0; j < oData.results.length; j++) {
									if (bp === oData.results[j].BusinessProcess) {
										pm_score = +pm_score + +oData.results[j].ParameterScore;

										counter_of_bp = counter_of_bp + 1;

									}

								}
							}

						} else {
							for (var j1 = 0; j1 < oData.results.length; j1++) {
								if (bp === oData.results[j1].BusinessProcess) {
									pm_score = +pm_score + +oData.results[j1].ParameterScore;

									counter_of_bp = counter_of_bp + 1;

								}

							}
						}
						var final_obj = {};
						if (status === 'false') {
							abpc_score = pm_score / counter_of_bp;
							if (abpc_score >= 1 && abpc_score <= 1.5) {
								arr_CL.push('N');
								final_obj['Parameter_Score_Complexity'] = 'N';

							}
							if (abpc_score >= 1.51 && abpc_score <= 1.99) {
								arr_CL.push('M');
								final_obj['Parameter_Score_Complexity'] = 'M';
							}
							if (abpc_score >= 2 && abpc_score <= 3) {
								arr_CL.push('H');
								final_obj['Parameter_Score_Complexity'] = 'H';
							}

							final_obj['Business_Process'] = bp;
							final_obj['ABPC_Score'] = abpc_score;

							arr_evalbp.push(bp);
							arr_pscore.push(pm_score);
							arr_abpc.push(abpc_score);
							finaldata.push(final_obj);

						}
					}

					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel1.setData(finaldata);

				/*	var oTooltip = new sap.viz.ui5.controls.VizTooltip({});
					oTooltip.connect(oVizFrame.getVizUid());*/

					oVizFrame = this.oVizFrame = oview.byId("idVizFrame");

					oVizFrame.setVizProperties({

						title: {
							visible: false

						},

						legend: {
							visible: true,
							title: {
								visible: false
							},
							maxNumOfItems: 150,
							isScrollable: false

						},

						legendGroup: {

							layout: {

								position: 'bottom',
								maxWidth: 100,
								alignment: 'center'

							}

						},

						plotArea: {
							dataLabel: {
								visible: true

							},
							dataPointStyle: {
								"rules": [{
									"dataContext": {
										"ParameterScoreComplexity": "N"
									},
									"properties": {
										"color": "#00B050"
									},
									"displayName": "N"

								}, {
									"dataContext": {
										"ParameterScoreComplexity": "M"
									},
									"properties": {
										"color": "#FFC300"
									},
									"displayName": "M"
								}, {
									"dataContext": {
										"ParameterScoreComplexity": "H"
									},
									"properties": {
										"color": "#FF0000"
									},
									"displayName": "H"

								}]

							}

						}

					});

					var oDataset = new sap.viz.ui5.data.FlattenedDataset({

						// a Bar Chart requires exactly one dimension (x-axis) 
						dimensions: [{
							axis: 1, // must be one for the x-axis, 2 for y-axis
							name: 'Business_Process',
							value: "{Business_Process}"
						}, {

							axis: 1, // must be one for the x-axis, 2 for y-axis
							name: 'ParameterScoreComplexity',
							value: "{Parameter_Score_Complexity}"

						}],

						// it can show multiple measures, each results in a new set of bars in a new color 
						measures: [

							{
								name: 'ABPC_Score',
								value: '{ABPC_Score}'
							}
						],

						// 'data' is used to bind the whole data collection that is to be displayed in the chart 
						data: {
							path: "/"
						}

					});

					var oBarChart = new sap.viz.ui5.Pie({
						width: "80%",
						height: "600px",
						plotArea: {
							//'colorPalette' : d3.scale.category20().range()
						},
						title: {
							visible: true,
							text: 'Profit and Revenue By Country'
						},
						legendGroup: {
							layout: {

								position: 'bottom',

								maxWidth: 100,

								alignment: 'center'

							}
						},
						dataset: oDataset
					});

					oBarChart.setModel(oModel1);
				//	t.oVizFrame.addContent(oBarChart);
					oview.ByID("pid").addContent(oBarChart);
					/*	var opage = oview.byId("idVizFrame");
			opage.addContent(oBarChart);*/
					//t.oVizFrame.addContent(oBarChart);
					/*		var opage = oview.byId("pid");
							opage.addContent(oBarChart);
							oview.setModel(oModel1);*/
				},
				fnError = function(oerror) {

				};
			oViewModel.read(calltype, {
				filters: aFilter,
				success: fnSuccess.bind(this),
				error: fnError.bind(this)
			});

		},
		analysistype: function(e) {
			var idx = e.getParameter("selectedIndex");
			var button = e.getSource().getButtons()[idx];
			type = button.getText();

		},
		module: function(e) {
			var idx = e.getParameter("selectedIndex");
			var button = e.getSource().getButtons()[idx];
			modulename = button.getText();

		}

	});
});