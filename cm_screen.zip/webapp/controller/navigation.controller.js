sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageToast",
	"sap/ui/core/routing/History"
], function(Controller, JSONModel, Filter, FilterOperator, MessageToast, History) {
	"use strict";
	jQuery.sap.declare("sap.ui.demo.wt.pie_xls.xlsx");
	jQuery.sap.declare("sap.ui.demo.wt.pie_xls.jszip");
	var value = "";
	var oModel = "";

	return Controller.extend("sap.ui.demo.wt.controller.navigation", {
		oVizFrame: null,
		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("navigation").attachPatternMatched(this._onObjectMatched, this);
			oModel = sap.ui.getCore().getModel("MyJSONData");
			var t = this;

			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				legend: {
					visible: true,
					title: {
						visible: false
					},
					maxNumOfItems: 150,
					isScrollable: false

				},
				title: {
					visible: false

				},

				plotArea: {
					dataLabel: {
						visible: false

					}
				},

				legendGroup: {

					layout: {
						position: 'bottom',
						maxWidth: 100,
						alignment: 'center'

					}

				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				}
			});
			t.oVizFrame.setModel(oModel);
			var oTooltip = new sap.viz.ui5.controls.VizTooltip({});
			oTooltip.connect(oVizFrame.getVizUid());
			var popFormat = "__UI5__FloatMaxFraction2";
			oTooltip.setFormatString(popFormat);

		},

		_onObjectMatched: function(oEvent) {
			value = oEvent.getParameter("arguments").complexity;
			if (value !== "") {
				var pos = value.indexOf("5");
				if (pos !== -1) {
					// to replace "/" as 5 in complexity area column 
					value = value.replace(/5/g, "/");
				}

			}
			var oview = this.getView();
			var afilters = [];
			var filter = new sap.ui.model.Filter("COMPLEXITY_AREA",
				sap.ui.model.FilterOperator.EQ, value);

			afilters.push(filter);
			var data = oview.byId("dataset");
			var oBinding = data.getBinding("data");
			oBinding.filter(afilters);
			var oViewModel = new sap.ui.model.json.JSONModel({
				Area: value
			});
			oview.setModel(oViewModel, "navview");

		},

		onNavBack: function(oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);

			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("navigation", true);
			}
		}

	});

});